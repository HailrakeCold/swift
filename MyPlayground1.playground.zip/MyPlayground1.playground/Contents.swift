
import UIKit

enum Rank {
    case scout
    case battleBrother
    case sergeant
    case veteran
    case captain
    case chapterMaster
    case chaplain
    
    func description() -> String {
        switch self {
        case .scout:
            return "Молодой рекрут, ещё не проверенный в бою."
        case .battleBrother:
            return "Полноценный воин Космодесанта."
        case .sergeant:
            return "Командует отрядом в бою."
        case .veteran:
            return "Опытный воин, прошедший сотни битв."
        case .captain:
            return "Один из командиров роты."
        case .chapterMaster:
            return "Верховный командир главы. Как Данте."
        case .chaplain:
            return "Духовный лидер роты, вдохновляющий братьев на бой."
        }
    }
}

enum Weapon {
    case bolter
    case chainsword
    case plasmaGun
    case powerFist
    
    func nameOfWeapon() -> String {
        switch self {
        case .bolter:
            return "Болтер"
        case .chainsword:
            return "Цепной меч"
        case .plasmaGun:
            return "Плазма пистолет"
        case .powerFist:
            return "Силовой кулак"
        }
    }
}

struct SpaceMarine {
    var name: String
    var rank: Rank
    var weapon : Weapon
    func report() {
        print("\(name): \(rank.description()) Использует \(weapon.nameOfWeapon()) как орудие.")
    }
}


let squad: [SpaceMarine] = [
    SpaceMarine(name: "Dante", rank: .chapterMaster,weapon: .plasmaGun),
    SpaceMarine(name: "Astorath", rank: .veteran, weapon: .bolter),
    SpaceMarine(name: "Lemartes", rank: .sergeant, weapon: .chainsword),
    SpaceMarine(name: "Thane", rank: .battleBrother, weapon: .bolter),
    SpaceMarine(name: "Aramus", rank: .scout, weapon: .bolter),
    SpaceMarine(name: "Gilidore", rank: .chaplain, weapon: .powerFist)
]

print("=== Squad Report ===")
for (index, marine) in squad.enumerated() {
    print("\(index + 1). ", terminator: "")
    marine.report()
}

func filterVeterans(from marines: [SpaceMarine]) -> [SpaceMarine] {
    let veterans = marines.filter { marine in
        marine.rank == .veteran || marine.rank == .sergeant
    }

    print("\n=== Ветераны отряда ===")
    print("Количество ветеранов: \(veterans.count)")
    
    for marine in veterans {
        marine.report()
    }

    return veterans
}



func weaponStats(from marines: [SpaceMarine]) {
    var stats: [Weapon: Int] = [:]

    for marine in marines {
        let weapon = marine.weapon
        stats[weapon, default: 0] += 1
    }

    print("\n=== Вооружение отряда ===")
    for (weapon, count) in stats {
        print("- \(weapon.nameOfWeapon()): \(count)")
    }
}

weaponStats(from: squad)
filterVeterans(from: squad)

